#include<stdio.h>

int main() {
	int a = 5;
	int b = 3;
	printf("Product: %d\n",a*b);
}
