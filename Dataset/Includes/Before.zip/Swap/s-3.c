#include<stdio.h>
int main() {
	int a = 3;
	int b = 5;

	printf("The swapped numbers are %d and %d",b, a);
}
