#include<stdio.h>
int main() {
	int a = 10;
	int b = 15;
	printf("%d %d\n",a+b, a-b);
}
