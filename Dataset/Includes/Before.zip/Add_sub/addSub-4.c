#include<stdio.h>
int main() {
	printf("%d %d\n",25, -5);
}
