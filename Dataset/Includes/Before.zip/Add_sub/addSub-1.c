#include<stdio.h>
int main() {
	int a = 10;
	int b = 15;
	int c = a + b;
	int d = a - b;
	printf("%d %d\n",c,d);
}
