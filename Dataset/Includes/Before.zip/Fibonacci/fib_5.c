#include<stdio.h>
int fib(int n) {
if(n <= 1) 
    //format changesasdasdasd

    return n;

return fib(n-1) + fib(n-2);
}

int main() {
int n = 10;
/*
haha, i am going to get away with plagiarism by adding comments!!!
*/
int res = fib(n);

printf("%d\n",res);
}
